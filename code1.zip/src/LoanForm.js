import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import './App.css';
const LoanForm = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    fullName: "",
    loanAmount: "",
    purpose: "House",
    tenure: "",
  });
  const [errors, setErrors] = useState({});

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const validationErrors = {};
    const { fullName, loanAmount, tenure } = formData;
    // Validations rules: if valid than navigate to welcome page otherwies 
    // navigate to error page
    const loan = Number(loanAmount);
    if (!loanAmount || isNaN(loan) || loan < 1000 || loan > 1000000){
      validationErrors.loanAmount = "/loan amount must be between 1000 and 1000000/i";
    }
    if (!fullName.trim()){
      validationErrors.fullName = "/Please enter your full name/i";
    }
    const years = Number(tenure);
    if (!tenure || isNaN(years) || years < 1 || years > 30){
      validationErrors.tenure = "/Tenure must be between 1 and 30 years/i";
    }
    
    if(Object.keys(validationErrors).length>0){
      setErrors(validationErrors)
    }else{
      navigate("/welcome");
    }

  };

  return (
    <div>
      <h1 className="header">Bank Loan Form</h1>

      {/* Create Loan Form HTML */}
      <form onSubmit={handleSubmit}>
        <label aria-labelledby="">/loan amount/i<input type="text" name="loanAmount" onChange={handleChange}></input></label>
        {errors.loanAmount && <p>{errors.loanAmount}</p>}
        <label aria-labelledby="">/full name/i<input type="text" name="fullName" onChange={handleChange}></input></label>
        {errors.fullName && <p>{errors.fullName}</p>}
        <label aria-labelledby="">/tenure/i<input type="text" name="tenure" onChange={handleChange}></input></label>
        {errors.tenure && <p>{errors.tenure}</p>}
        <button type="submit">/submit/i</button>
      </form>
    </div>
  );
};

export default LoanForm;
