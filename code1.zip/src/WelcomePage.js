// WelcomePage.js

import React from 'react';

const WelcomePage = () => {
    // welcome message should be shown in h1
};

export default WelcomePage;
