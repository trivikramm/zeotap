package com.example.demo.service.impl;

import com.example.demo.entity.Game;
import com.example.demo.repository.GameRepository;
import com.example.demo.service.GameService;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class GameServiceImpl implements GameService {
    private final GameRepository repo;
    public GameServiceImpl(GameRepository repo) { this.repo = repo; }

    @Override
    public Game getGameById(Long id) { /* TODO */ return null; }

    @Override
    public Game createGame(Game game) { /* TODO */ return null; }

    @Override
    public List<Game> getAllGames() { /* TODO */ return null; }
}