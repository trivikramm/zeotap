package com.example.demo.entity;

import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import java.util.List;

@Entity
public class Team {
    @Id
    private Long teamId;
    private String teamName;
    @ElementCollection
    private List<String> players;
    // Getters and setters...
}