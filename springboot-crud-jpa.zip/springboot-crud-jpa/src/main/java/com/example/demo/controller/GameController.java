package com.example.demo.controller;

import com.example.demo.entity.Game;
import com.example.demo.service.GameService;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/games")
public class GameController {
    private final GameService service;
    public GameController(GameService service) { this.service = service; }

    @GetMapping("/{id}")
    public Game getById(@PathVariable Long id) { /* TODO */ return null; }

    @PostMapping
    public Game create(@RequestBody Game game) { /* TODO */ return null; }

    @GetMapping
    public List<Game> getAll() { /* TODO */ return null; }
}