package com.example.demo.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Game {
    @Id
    private Long gameId;
    private String gameName;
    private String genre;
    // Getters and setters...
}