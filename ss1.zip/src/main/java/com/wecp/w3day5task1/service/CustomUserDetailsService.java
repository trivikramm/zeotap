package com.wecp.w3day5task1.service;


import com.wecp.w3day5task1.entity.User;
import com.wecp.w3day5task1.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.Optional;
@Service
public class CustomUserDetailsService implements UserDetailsService {


    @Autowired
    private UserRepository userRepository;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

        // method to load a user by its username
        User user = userRepository.findByUsername(username)
        .orElseThrow(()-> new UsernameNotFoundException("Exception"+ username));

        return org.springframework.security.core.userdetails.User(
            user.getUsername()
        );

    }
}

