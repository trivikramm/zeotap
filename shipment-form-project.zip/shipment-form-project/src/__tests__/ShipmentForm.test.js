
import React from 'react';
import { render, fireEvent, waitFor, screen } from '@testing-library/react';
import ShipmentForm from '../components/ShipmentForm';

test('Empty Form Submission', async () => {
  render(<ShipmentForm />);
  fireEvent.click(screen.getByText('Register Shipment'));
  await waitFor(() => {
    expect(screen.getByText('Sender is required')).toBeInTheDocument();
    expect(screen.getByText('Receiver is required')).toBeInTheDocument();
    expect(screen.getByText('Origin is required')).toBeInTheDocument();
    expect(screen.getByText('Destination is required')).toBeInTheDocument();
    expect(screen.getByText('Status is required')).toBeInTheDocument();
    expect(screen.getByText('Expected Delivery is required')).toBeInTheDocument();
  });
});

test('Valid Form Submission', async () => {
  render(<ShipmentForm />);
  fireEvent.change(screen.getByLabelText('Sender:'), { target: { value: 'Tech Corp' } });
  fireEvent.change(screen.getByLabelText('Receiver:'), { target: { value: 'John Doe' } });
  fireEvent.change(screen.getByLabelText('Origin:'), { target: { value: 'New York' } });
  fireEvent.change(screen.getByLabelText('Destination:'), { target: { value: 'San Francisco' } });
  fireEvent.change(screen.getByLabelText('Status:'), { target: { value: 'In Transit' } });
  fireEvent.change(screen.getByLabelText('Expected Delivery:'), { target: { value: '2023-09-20' } });

  fireEvent.click(screen.getByText('Register Shipment'));

  await waitFor(() => {
    expect(screen.queryByText('Sender is required')).not.toBeInTheDocument();
    expect(screen.queryByText('Receiver is required')).not.toBeInTheDocument();
    expect(screen.queryByText('Origin is required')).not.toBeInTheDocument();
    expect(screen.queryByText('Destination is required')).not.toBeInTheDocument();
    expect(screen.queryByText('Status is required')).not.toBeInTheDocument();
    expect(screen.queryByText('Expected Delivery is required')).not.toBeInTheDocument();
  });
});
