// ShipmentForm.js
import React, { useState } from "react";

function ShipmentForm() {
  const [formData, setFormData] = useState({
    sender: "",
    receiver: "",
    origin: "",
    destination: "",
    status: "",
    expectedDelivery: "",
  });

  const [errors, setErrors] = useState({
    sender: "",
    receiver: "",
    origin: "",
    destination: "",
    status: "",
    expectedDelivery: "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const validateForm = () => {
    // ✅ Validate fields and set error messages
    let isValid = true;
    const newErrors = {};
  };

  const handleSubmit = (e) => {
    e.preventDefault();
  };

  return (
    <div className="shipment-form-container">
      <h2>Register New Shipment</h2>
      <form>
        <label>
          Sender: 
          <input
            type="text"
            name="sender"
            value={formData.sender}
            onChange={handleChange}
          />
        </label>
      </form>
    </div>
  );
}

export default ShipmentForm;
