
import React from 'react';
import ShipmentForm from './components/ShipmentForm';

function App() {
  return <ShipmentForm />;
}

export default App;
